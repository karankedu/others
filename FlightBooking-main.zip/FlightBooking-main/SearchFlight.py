class SearchFlight:
     
    """ Booking Class """
 
    def __init__(self, search_flight_factory = None):
        self.search_flight_factory = search_flight_factory
 
    def show_search_flight(self):
        search_flight = self.search_flight_factory()

class International:
    def source(self):
        pass
    
    def destination(self):
        pass
    
    def travellerr_count(self):
        pass
    
    def booking_class(self):
        pass
 
 
class Domestic:
  
    def source(self):
        pass
    
    def destination(self):
        pass
    
    def travellerr_count(self):
        pass
    
    def booking_class(self):
        pass
 

if __name__ == "__main__":
 
    flight = SearchFlight('Domestic')
    flight.show_search_flight()
