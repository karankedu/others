class TicketBooking:
    
    def __init__(self):
        pass
    
    def available_seat(self):
    	pass

    @classmethod
    def allocate_seat(cls, seat):
        pass

    @classmethod
    def release_seat(cls, seat):
        pass

    def book_flight(self, **args, **kwargs):
        pass

    def generate_pnr(self):
        pass

    def check_details(self):
        pass

    def ticket_summary(self):
        pass

    def initiate_payment(self):
        pass


def Factory(booking="ticket_booking"):
	"""Factory Method"""
    factory_data = {"ticket_booking": TicketBooking}
	return factory_data[booking]


if __name__ == "__main__":

	""" We can use flyweight design patterns in case want to utilize common resources"""
    f = Factory("ticket_booking")
    f.available_seat()
 