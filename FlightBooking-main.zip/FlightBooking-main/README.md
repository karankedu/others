# FlightBooking
Flight Booking Assignments

Considering below details to build Flight Booking system

Domestic/Internation 

Travelling selection
    - Oneway
    - Roundtrip
    - Multicity

Searching Flight Attributes
1. Source and Destination
2. Departure Date
3. Return Date (If Roundtrip selected)
4. Travellers Count
5. Class
    a. Economy
    b. Prem. Economy
    c. Business Class


Search results based on the various attributes passed
-> Flight company - Time - 1 Stop/Non stop - Price
-> Choose flight and proceed for booking 
-> Lock the seat for time period so other user can't book same seat (In case user will not proceed then seat will be available for the other user after lock period)
-> Enter travellers details
-> Calculate total price including tax 
-> Choose Payment options and offer code
-> Proceed payment 
-> booking confirmed 
-> Send email notification on successfully booking

Implementations should have
    - Both RDMS & NoSql for the faster result
    - Caching like Redis, memcach or equivallent caching mechanism


Module list based on the above details.
Flight Database -> Flight Management (Administrator)
    - Flight Details
    - Seat Deatils, Loction Map & concurrency control
    - Controlling seat availability
    - Flight Location Map

Traveller Database
    - Traveller Details

Payment/Transaction Database
    - Bank API gateway or Codeshare
    - We should use ACID properties

Booking Database
    - Booking History
    - Booking Details
    - Ticket Details
    - PNR details

Notification Database
    - Notify Details 
    - Message queue systme for async task

Log Management
    - To identify bug and fix issue



