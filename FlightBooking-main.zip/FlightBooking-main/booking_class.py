class BookingClass:
     
    """ Booking Class """
 
    def __init__(self, booking_class_factory = None):
        self.booking_class_factory = booking_class_factory
 
    def show_booking_class(self):
        booking_class = self.booking_class_factory()

 
class Economy:
  
    def Fare(self):
        pass
    
    def seat(self):
        pass
 

class PremEconomy:
 
    def Fare(self):
        pass
    
    def seat(self):
        pass
 
class BusinessClass:
 
    def Fare(self):
        pass
    
    def seat(self):
        pass
 

if __name__ == "__main__":
 
    course = BookingClass('Economy')
    course.show_booking_class()
